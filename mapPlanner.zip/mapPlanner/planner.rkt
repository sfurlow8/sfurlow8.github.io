#lang dssl2

# Final project: Trip Planner
#
# ** You must work on your own for this assignment. **

let eight_principles = ["Know your rights.", "Acknowledge your sources.", "Protect your work.", "Avoid suspicion.", "Do your own work.", "Never falsify a record or permit another person to do so.", "Never fabricate data, citations, or experimental results.", "Always tell the truth when discussing your work with your instructor."]    

# most updated version

# Your program will most likely need a number of data structures, many of
# which you've implemented in previous homeworks.
# We have provided you with compiled versions of homework 3, 4, and 5 solutions.
# You can import them as described in the handout.
# Be sure to extract `project-lib.zip` is the same directory as this file.
# You may also import libraries from the DSSL2 standard library (e.g., cons,
# array, etc.).
# Any other code (e.g., from lectures) you wish to use must be copied to this
# file.

import cons
import sbox_hash
import 'project-lib/dictionaries.rkt'
import 'project-lib/graph.rkt'
import 'project-lib/binheap.rkt'

### Basic Vocabulary Types ###

#  - Latitudes and longitudes are numbers:
let Lat?  = num?
let Lon?  = num?
#  - Point-of-interest categories and names are strings:
let Cat?  = str?
let Name? = str?

# ListC[T] is a list of `T`s (linear time):
let ListC = Cons.ListC

# List of unspecified element type (constant time):
let List? = Cons.list?


### Input Types ###

#  - a SegmentVector  is VecC[SegmentRecord]
#  - a PointVector    is VecC[PointRecord]
# where
#  - a SegmentRecord  is [Lat?, Lon?, Lat?, Lon?]
#  - a PointRecord    is [Lat?, Lon?, Cat?, Name?]


### Output Types ###

#  - a NearbyList     is ListC[PointRecord]; i.e., one of:
#                       - None
#                       - cons(PointRecord, NearbyList)
#  - a PositionList   is ListC[Position]; i.e., one of:
#                       - None
#                       - cons(Position, PositionList)
# where
#  - a PointRecord    is [Lat?, Lon?, Cat?, Name?]  (as above)
#  - a Position       is [Lat?, Lon?]


# Interface for trip routing and searching:
interface TRIP_PLANNER:
    # Finds the shortest route, if any, from the given source position
    # (latitude and longitude) to the point-of-interest with the given
    # name. (Returns the empty list (`None`) if no path can be found.)
    def find_route(
            self,
            src_lat:  Lat?,     # starting latitude
            src_lon:  Lon?,     # starting longitude
            dst_name: Name?     # name of goal
        )   ->        List?     # path to goal (PositionList)

    # Finds no more than `n` points-of-interest of the given category
    # nearest to the source position. (Ties for nearest are broken
    # arbitrarily.)
    def find_nearby(
            self,
            src_lat:  Lat?,     # starting latitude
            src_lon:  Lon?,     # starting longitude
            dst_cat:  Cat?,     # point-of-interest category
            n:        nat?      # maximum number of results
        )   ->        List?     # list of nearby POIs (NearbyList)

struct position:
    let lat: Lat?
    let lon: Lon?

struct road:
    let p1: position?
    let p2: position?
        
struct poi:
    let posn: position?
    let cat: Cat?
    let name: Name?
    
    
    
class TripPlanner (TRIP_PLANNER):
    let road_structs
    let poi_structs
    # let roads
    # let routes
    let names_to_points
    let points_to_nodes
    let nodes_to_points
    let nodes_to_pois
    let road_graph


    def __init__(self, roads: vec?, pois: vec?):
        self.road_structs = [None; len(roads)]
        for i in range(len(roads)):
            let r = roads[i]
            let endpoint1 = position(r[0], r[1])
            let endpoint2 = position(r[2], r[3])
            self.road_structs[i] = road(endpoint1, endpoint2) # vector of road structs
        
        self.poi_structs = [None; len(pois)]  
        for i in range(len(pois)):
            let p = pois[i]
            let latitude = p[0]
            let longitude = p[1]
            let posn = position(latitude, longitude)
            let cat = p[2]
            let name = p[3]
            self.poi_structs[i] = poi(posn, cat, name) # vector of poi structs
        # road_graph = WuGraph(len(roads))
        
        self.names_to_points = HashTable(len(pois), make_sbox_hash()) # map names of pois to their positions
        for i in range(len(self.poi_structs)):
            let poi = self.poi_structs[i]
            let name = poi.name
            let posn = poi.posn
            self.names_to_points.put(name, posn)
            
        # want to end up with a graph with positions as nodes and edges as roads
        # positions can't be nodes (must be natural numbers), make a dictionary mapping node ids to positions
        # graph will not have more nodes than the sum number of roads and pois (hash table may have empty spaces)
        self.points_to_nodes = HashTable(2*len(roads)+len(pois), make_sbox_hash())
        let node_id = 0
        
        for i in range(len(roads)):
            let road = roads[i]
            let p1 = position(road[0], road[1])
            let p2 = position(road[2], road[3])
            if not self.points_to_nodes.mem?(p1):
                self.points_to_nodes.put(p1, node_id)
                node_id = node_id + 1 # have to increment node_id every time you put one
                # don't do nested if statements, incrementing node_id gets too nuanced
            
            if not self.points_to_nodes.mem?(p2):
                self.points_to_nodes.put(p2, node_id)
                node_id = node_id + 1
        for i in range(len(self.poi_structs)):
            let this_poi = self.poi_structs[i]            
            if not self.points_to_nodes.mem?(this_poi.posn):
                self.points_to_nodes.put(this_poi.posn, node_id)
                node_id = node_id + 1
            ######################### ?????????? How to give node_ids to isolated POIs
                # previous for loop does this
        
        self.nodes_to_points = [None; self.points_to_nodes.len()] # map node numbers back to their positions in the graph
        for i in range(len(self.road_structs)):
            let n1 = self.points_to_nodes.get(self.road_structs[i].p1)
            let n2 = self.points_to_nodes.get(self.road_structs[i].p2)
            self.nodes_to_points[n1] = self.road_structs[i].p1
            self.nodes_to_points[n2] = self.road_structs[i].p2
        for i in range(len(self.poi_structs)): # catch isolated pois
            let this_poi = self.poi_structs[i]
            let node = self.points_to_nodes.get(this_poi.posn)
            self.nodes_to_points[node] = this_poi.posn
        
        
            
        self.nodes_to_pois = [None; self.nodes_to_points.len()] # map node numbers to pois
        for i in range(len(self.poi_structs)):
            let p = self.poi_structs[i]
            let node = self.points_to_nodes.get(p.posn)
            let the_pois = self.nodes_to_pois[node]
            self.nodes_to_pois[node] = cons(p, the_pois) # vector of cons objects
            
                
        self.road_graph = WuGraph(self.points_to_nodes.len())
        # set each edge in road_graph between node_ids with weights as the euclidean distance between nodes
        for i in range(len(roads)):
            let r = roads[i]
            let p1 = position(r[0], r[1])
            let p2 = position(r[2], r[3])
            let node1 = self.points_to_nodes.get(p1) # returns node id of coordinate p1
            let node2 = self.points_to_nodes.get(p2)
            let euc_dist = (((r[2]-r[0])*(r[2]-r[0]))+((r[3]-r[1])*(r[3]-r[1]))).sqrt() # caret function not for exponents 
            self.road_graph.set_edge(node1, node2, euc_dist)
            

                
    def find_route(self, src_lat: Lat?, src_lon: Lon?, dst_name: Name?):
        if not self.names_to_points.mem?(dst_name): # if the dst_name isn't on the map, return empty list
            return None
        
        # take start position and find sssp to position of POI - use Bellman Ford or Dijkstra?
        # get position of poi from names_to_points
        # get node_id of start and dest from points_to_nodes
        let src_posn = position(src_lat, src_lon)
        if not self.points_to_nodes.mem?(src_posn): # if the start position is not on the map, return empty list
            return None
        let dst_posn = self.names_to_points.get(dst_name)
        #print(str(dst_posn))
        let src_node = self.points_to_nodes.get(src_posn)
        #print(str(src_node))
        let dst_node = self.points_to_nodes.get(dst_posn)
        #print(str(dst_node))
        
        let route = None
        if src_posn == dst_posn:
            route = cons([src_lat, src_lon], route)
            return route
        
        let sssp_path = sssp(self.road_graph, src_node)
        let sssp_preds = sssp_path.preds
        let curr_node = dst_node
        while sssp_preds[curr_node] is not None:
            #print(str(curr_node))
            # need a dictionary to map nodes_to_points 
            let curr_point = self.nodes_to_points[curr_node]
            route = cons([curr_point.lat, curr_point.lon], route)
            curr_node = sssp_preds[curr_node] # move along the sssp to the next node that curr_node is connected to
        if route is not None: # if a path exists, cons the starting position to the path found by the while loop (otherwise return the empty list)
            route = cons([src_lat, src_lon], route)
        return route
        
                
    def find_nearby(self, src_lat: Lat?, src_lon: Lon?, dst_cat: Cat?, n: nat?):
        let src_posn = position(src_lat, src_lon)
        let src_node = self.points_to_nodes.get(src_posn)
        # take start position, find nearest POI in category, repeat n times
        # use find_route in here? don't need to
        let sssp_path = sssp(self.road_graph, src_node)
        let sssp_dists = sssp_path.dists
               
        let heap_len = len(self.nodes_to_points) # want binheap to have enough space for all vertices
        let heap = BinHeap(heap_len, lambda x,y: x.dist < y.dist)
        
        let count = 1 
        let nearby = None
        for i in range(len(sssp_dists)):
            if sssp_dists[i] is not inf:
                let ins = node_priority(i, sssp_dists[i])
                heap.insert(ins) # fill heap with distances from sssp output, distances act as priorities in the heap
        while heap.len() > 0 and count <= n: # loop through until heap is empty or you exceed n
            let close_node = heap.find_min().node_id
            heap.remove_min()
            let close_point = self.nodes_to_pois[close_node] 
            
            while close_point is not None and count <= n: # loop through n nearby nodes and if it matches the desired category, cons it to nearby output
                let curr_node = close_point.data
                let curr_cat = curr_node.cat
                if curr_cat == dst_cat:
                    let nearby_info = [curr_node.posn.lat, curr_node.posn.lon, curr_node.cat, curr_node.name]
                    nearby = cons(nearby_info, nearby) # nearby will eventually return cons list of pois
                    count = count + 1
                close_point = close_point.next
        return nearby           

        
struct node_priority: # node_priority struct holds a node id and distance (to be used as priority in binheap)
    let node_id: nat?
    let dist: num?
    
struct sssp_output: # sssp algorithm will return an sssp_output struct with the vectors of distances and predecessors
    let dists: vec?
    let preds: vec?
    
## implement sssp algorithm using dijkstra's algorithm
# follow pseudo code in sssp lecture slide 20   
        # todo is PQ that keeps track of the edges we wanna add
        # "priority" is determined by distance
        # highest priority = shortest distance   
        # priority queue w binheap implementation
        # order binheap with smallest distance as more urgent priority            
def sssp(graph: WuGraph?, start: nat?):
    let edges = graph.get_all_edges() # want BinHeap to be number of edges in the graph
    let edg_len = 0
    while edges is not None: # count number of edges (get_all_edges returns cons list)
        edg_len = edg_len + 1
        edges = edges.next
    
    let todo = BinHeap(edg_len, lambda x,y: x.dist<y.dist) 
    let dists = [inf; graph.len()] # start by assuming distance between every point is infinite (not connected)
    dists[start] = 0
    let preds = [None; graph.len()] 
    let done = [False; graph.len()] # none of the nodes have been visited at the start
    todo.insert(node_priority(start, 0))
    while todo.len() > 0:
        let v_d = todo.find_min() # find_min outputs elements in the heap (make elements structs w vertex and dist)
        let v = v_d.node_id
        todo.remove_min()
        if done[v] == False:
            # if v has not been visited, relax outgoing edges
            let adj = graph.get_adjacent(v)
            while adj is not None:
                # print(str(adj.data))
                let u = adj.data
                # let u = u_d.node_id
                let w = graph.get_edge(v, u)
                if dists[v] + w < dists[u]:
                    dists[u] = dists[v] + w
                    preds[u] = v
                    # add neighbor to priority queue
                    todo.insert(node_priority(u, dists[u]))
                adj = adj.next # move onto next adjacent node
            done[v] = True  # after relaxing, mark v as done
    let out = sssp_output(dists, preds) # returns a struct with final dists and preds vectors as fields
    return out      
  
    
    
                                                   
# run my_first_example() in console to see what the data structures look like
def my_first_example():
    return TripPlanner([[0,0, 0,1], [0,0, 1,0]],
                       [[0,0, "bar", "The Empty Bottle"],
                        [0,1, "food", "Pelmeni"]])

                        
test 'My first find_route test':
   assert my_first_example().find_route(0, 0, "Pelmeni") == \
       cons([0,0], cons([0,1], None))
      

test 'My first find_nearby test':
    assert my_first_example().find_nearby(0, 0, "food", 1) == \
        cons([0,1, "food", "Pelmeni"], None)

def example_from_handout():
    return TripPlanner([[0,0, 1,0], [1,0, 1,1], [1,1, 0,1], [0,1, 0,0],
                         [0,1, 0,2], [1,1, 1,2], [0,2, 1,2], [1,3, 1,2], [1,3, -0.2,3.3]],
                         [[0,0, "food", "Sandwiches"], 
                         [0,1, "food", "Pasta"],
                         [1,1, "bank", "Local Credit Union"],
                         [1,3, "bar", "Bar None"],
                         [1,3, "bar", "H Bar"],
                         [-0.2, 3.3, "food", "Burritos"]])
                         
test 'My second find_route test':
   assert example_from_handout().find_route(1, 2, "Burritos") == \
       cons([1,2], cons([1,3], cons([-0.2, 3.3], None)))
       
test 'find_route 3':
    assert example_from_handout().find_route(1, 1, "Burritos") == \
        cons([1,1], cons([1,2], cons([1,3], cons([-0.2, 3.3], None))))
        
test 'My second find_nearby test':
    assert example_from_handout().find_nearby(1, 3, "food", 1) == \
        cons([-0.2, 3.3, "food", "Burritos"], None)
        
test 'find_nearby 3':
    assert example_from_handout().find_nearby(0, 2, "food", 3) == \
        cons([-0.2, 3.3, "food", "Burritos"], cons([0, 0, "food", "Sandwiches"], cons([0, 1, "food", "Pasta"], None)))
    assert example_from_handout().find_nearby(0, 2, "food", 4) == \
        cons([-0.2, 3.3, "food", "Burritos"], cons([0, 0, "food", "Sandwiches"], cons([0, 1, "food", "Pasta"], None)))
        
test 'nonexistent':
    assert example_from_handout().find_route(1, 1, "sushi") == None
    assert example_from_handout().find_nearby(0, 2, "school", 5) == None
    
def my_neighborhood():
    return TripPlanner([[0,0, 0,4], [0,0, 2, -1], [2, -1, 2,4]],
                        [[0, 0, "restaurant", "Blue Door"], [2, -1, "store", "TopDrawer"], [5, 0, "restaurant", "Athenian Rm"]])
                        
test 'my_neighborhood find_route':
    assert my_neighborhood().find_route(0,0, "Blue Door") == \
        cons([0, 0], None)
    assert my_neighborhood().find_route(2,4, "Blue Door") == \
        cons([2, 4], cons([2, -1], cons([0, 0], None))) 
    assert my_neighborhood().find_route(2,4, "Athenian Rm") == None  
    assert my_neighborhood().find_route(5,0, "Athenian Rm") == \
        cons([5, 0], None)
    assert my_neighborhood().find_route(5,0, "Blue Door") == None
    assert my_neighborhood().find_route(6,0, "Blue Door") == None
    assert my_neighborhood().find_route(0,0, "Fake place") == None
    
test 'my_neighborhood find_nearby':
    assert my_neighborhood().find_nearby(0, 4, "restaurant", 1) == \
        cons([0,0, "restaurant", "Blue Door"], None)
    assert my_neighborhood().find_nearby(0, 4, "restaurant", 5) == \
        cons([0,0, "restaurant", "Blue Door"], None)
    assert my_neighborhood().find_nearby(5, 0, "restaurant", 1) == \
        cons([5,0, "restaurant", "Athenian Rm"], None)
    assert my_neighborhood().find_nearby(5, 0, "store", 1) == None
    
    

